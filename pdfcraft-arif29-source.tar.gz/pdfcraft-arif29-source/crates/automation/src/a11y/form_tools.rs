use super::{Args, Automation, Result, ToolError, Value, failed, json, with_warnings, write_atomic};

/// A script's request to the viewer as the JSON that running a script reports (page numbers
/// 1-based); a side panel goes by its fixed id.
fn request_json(r: &pdfcraft_engine::js::Request) -> Value {
    use pdfcraft_engine::js::Request as R;
    match r {
        R::Reset(n) => json!({ "reset": n }),
        R::Print => json!({ "print": true }),
        R::GoToPage(p) => json!({ "page": p + 1 }),
        R::LaunchUrl(u) => json!({ "url": u }),
        R::Submit(u) => json!({ "submit": u }),
        R::Focus(f) => json!({ "focus": f }),
        R::FocusField { name, object_id } => json!({ "focus": name, "field_id": object_id }),
        R::Zoom(z) => json!({"zoom":z}),
        R::Beep => json!({ "beep": true }),
        R::Highlight(on) => json!({ "highlight": on }),
        R::SaveAs => json!({ "save_as": true }),
        R::OpenAttachment { name, open } => json!({ "attachment": name, "open": open }),
        R::ShowPanel(p) => json!({ "panel": p.id() }),
    }
}

/// The optional `field_id` argument: a field's identity from form_fields, selecting one of
/// fields sharing a name.
fn field_id(a: &Args) -> Result<Option<u64>> {
    a.0.get("field_id")
        .map(|v| {
            v.as_u64()
                .filter(|id| *id < 1 << 48)
                .ok_or_else(|| ToolError::InvalidArgs("field_id must be an integer between 0 and 281474976710655".into()))
        })
        .transpose()
}

/// A message a script showed, as `js_run` reports it: its text, title (null when it gave none),
/// icon and buttons.
pub(crate) fn alert_json(m: &pdfcraft_engine::js::Message) -> Value {
    json!({ "message": m.text, "title": m.title, "icon": m.icon.name(), "buttons": m.buttons.name() })
}

/// What scripts that ran unasked (a document's Will Save or Will Print actions) showed, said
/// or asked for, as tools report it.
pub(crate) fn js_output_json(out: &pdfcraft_engine::js::JsOutput) -> Value {
    json!({
        "alerts": out.alerts.iter().map(alert_json).collect::<Vec<_>>(),
        "console": out.console,
        "requests": out.requests.iter().map(request_json).collect::<Vec<_>>(),
        "errors": out.errors,
    })
}

impl Automation {
    /// `js_run`: run `script` in the document, or as button `field`'s script, and report its
    /// messages, console lines, requests, error, the failing document scripts' errors and result.
    pub(crate) fn js_run(&mut self, a: &Args) -> Result<Value> {
        let id = self.doc(a)?.id;
        let answers = match a.0.get("answers") {
            None => Vec::new(),
            Some(Value::Array(values)) if values.len() <= 32 => values
                .iter()
                .map(|v| match v {
                    Value::Null => Ok(None),
                    Value::String(s) if s.len() <= 4096 => Ok(Some(s.clone())),
                    _ => Err(ToolError::InvalidArgs("answers must contain strings or null".into())),
                })
                .collect::<Result<Vec<_>>>()?,
            _ => return Err(ToolError::InvalidArgs("answers must be an array of at most 32 strings or null".into())),
        };
        let identity = field_id(a)?;
        let (script, field) = (a.str("script")?, a.opt_str("field")?);
        let (mut o, edit) =
            self.session.with_own_js_output(id, |s| s.run_javascript_answers_target(id, script, field, identity, &answers)).map_err(failed)?;
        o.alerts.extend(edit.alerts);
        o.console.extend(edit.console);
        o.requests.extend(edit.requests);
        let reqs: Vec<Value> = o.requests.iter().map(request_json).collect();
        let alerts: Vec<Value> = o.alerts.iter().map(alert_json).collect();
        Ok(with_warnings(
            json!({ "alerts": alerts, "console": o.console, "requests": reqs, "error": o.error, "document_errors": o.doc_errors, "result": o.result }),
            edit.errors,
        ))
    }

    pub(crate) fn js_document_scripts(&self, a: &Args) -> Result<Value> {
        let list: Vec<Value> = self.doc(a)?.document_scripts().into_iter().map(|(n, s)| json!({ "name": n, "script": s })).collect();
        Ok(json!({ "scripts": list }))
    }

    /// `js_set_document_script`: set the document-level script `name` to `script`, or remove it
    /// when `script` is left out, as one undoable edit; returns the document's scripts.
    pub(crate) fn js_set_document_script(&mut self, a: &Args) -> Result<Value> {
        let edit = pdfcraft_engine::Edit::SetDocumentScript { name: a.str("name")?.into(), script: a.opt_str("script")?.map(str::to_string) };
        let id = self.doc(a)?.id;
        let warnings = self.apply_with_warnings(id, edit)?;
        Ok(with_warnings(self.js_document_scripts(a)?, warnings))
    }

    /// `form_set_script`: set field `field`'s JavaScript for `event` to `script`, or remove it when
    /// `script` is left out, as one undoable edit; returns the console output and errors.
    pub(crate) fn form_set_script(&mut self, a: &Args) -> Result<Value> {
        let edit = pdfcraft_engine::Edit::SetFieldScript {
            name: a.str("field")?.into(),
            event: a.str("event")?.into(),
            script: a.opt_str("script")?.map(str::to_string),
        };
        let id = self.doc(a)?.id;
        let ((), out) = self.session.with_own_js_output(id, |s| s.apply(id, edit)).map_err(failed)?;
        Ok(json!({ "field": a.str("field")?, "event": a.str("event")?, "console": out.console, "errors": out.errors }))
    }

    /// `form_focus`: field `field` (its 1-based `widget`) gains (`enter`) or loses (`exit`)
    /// focus, running its XFA scripts for that event; returns whether the form changed and what
    /// the scripts showed or asked for.
    pub(crate) fn form_focus(&mut self, a: &Args) -> Result<Value> {
        use pdfcraft_engine::js::FieldFocus;
        let focus = match a.str("event")? {
            "enter" => FieldFocus::Enter,
            "exit" => FieldFocus::Exit,
            other => return Err(ToolError::InvalidArgs(format!("event must be enter or exit, not {other:?}"))),
        };
        let name = a.str("field")?;
        let doc = self.doc(a)?;
        let field = doc.form.iter().find(|f| f.name == name).ok_or_else(|| failed(format!("there is no field named {name:?} (see form_fields)")))?;
        // A field with no widget (one only scripts or calculations use) has nothing to focus.
        let widgets = field.widgets.len();
        let widget = a.opt_int("widget")?.unwrap_or(1);
        let widget = usize::try_from(widget).ok().and_then(|w| w.checked_sub(1)).filter(|w| *w < widgets).ok_or_else(|| match widgets {
            0 => ToolError::InvalidArgs(format!("{name:?} has no widget to focus")),
            n => ToolError::InvalidArgs(format!("widget must be 1 to {n} for {name:?}")),
        })?;
        let id = doc.id;
        let changed = self.session.field_focus(id, name, widget, focus).map_err(failed)?;
        let out = self.session.take_js_output(id);
        let reqs: Vec<Value> = out.requests.iter().map(request_json).collect();
        Ok(
            json!({ "changed": changed, "alerts": out.alerts.iter().map(alert_json).collect::<Vec<_>>(), "console": out.console, "requests": reqs, "errors": out.errors }),
        )
    }

    /// `js_event`: run the JavaScript widget `widget` (1-based) of field `field` has for `event`
    /// (a trigger id: mouse_enter, mouse_exit, mouse_down, mouse_up, on_focus, on_blur); returns
    /// whether the form changed and what the script showed or asked for.
    pub(crate) fn js_event(&mut self, a: &Args) -> Result<Value> {
        let event = a.str("event")?;
        let trigger = pdfcraft_engine::FieldTrigger::from_id(event).ok_or_else(|| {
            ToolError::InvalidArgs(format!("event must be mouse_enter, mouse_exit, mouse_down, mouse_up, on_focus or on_blur, not {event:?}"))
        })?;
        let name = a.str("field")?;
        let identity = field_id(a)?;
        let doc = self.doc(a)?;
        let field =
            doc.form.iter().find(|f| f.name == name && identity.is_none_or(|i| pdfcraft_engine::js::field_object_id(f.obj) == i)).ok_or_else(
                || match identity {
                    Some(i) => failed(format!("there is no field named {name:?} with field_id {i} (see form_fields)")),
                    None => failed(format!("there is no field named {name:?} (see form_fields)")),
                },
            )?;
        let widgets = field.widgets.len();
        let widget = a.opt_int("widget")?.unwrap_or(1);
        let widget = usize::try_from(widget).ok().and_then(|w| w.checked_sub(1)).filter(|w| *w < widgets).ok_or_else(|| match widgets {
            0 => ToolError::InvalidArgs(format!("{name:?} has no widget")),
            n => ToolError::InvalidArgs(format!("widget must be 1 to {n} for {name:?}")),
        })?;
        let (id, object) = (doc.id, pdfcraft_engine::js::field_object_id(field.obj));
        // Only this event's output: what opening or an earlier tool left waiting stays.
        let (changed, out) =
            self.session.with_own_js_output(id, |s| s.field_trigger_target(id, name, Some(object), widget, trigger)).map_err(failed)?;
        let mut result = js_output_json(&out);
        result["changed"] = json!(changed);
        Ok(result)
    }

    /// `form_merge_data`: merge the form data files at `paths` into one CSV at `path`, a row per
    /// file; returns the path and the row and column counts.
    pub(crate) fn form_merge_data(&mut self, a: &Args) -> Result<Value> {
        let mut files = Vec::new();
        for p in a.strs("paths")? {
            let path = self.resolve(p, false)?;
            files.push((p.to_string(), crate::read_input_bytes(&path).map_err(|e| failed(format!("{p}: {e}")))?));
        }
        let csv = pdfcraft_engine::merge_data_files(&files).map_err(failed)?;
        let target = self.resolve(a.str("path")?, true)?;
        write_atomic(&target, csv.as_bytes())?;
        let columns = csv.lines().next().map_or(0, |h| h.split(',').count());
        Ok(json!({ "path": target.to_string_lossy(), "rows": files.len(), "columns": columns }))
    }

    pub(crate) fn form_detect_fields(&mut self, a: &Args) -> Result<Value> {
        let pages = if a.opt_ints("pages")?.is_some() { self.pages(a, "pages")? } else { Vec::new() };
        let id = self.doc(a)?.id;
        let found = self.session.detect_fields(id, &pages);
        let list: Vec<Value> = found
            .iter()
            .map(|(p, c)| {
                let (kind, comb) = match c.kind {
                    pdfcraft_engine::detect::Kind::Text => ("text", None),
                    pdfcraft_engine::detect::Kind::CheckBox => ("checkbox", None),
                    pdfcraft_engine::detect::Kind::Comb { cells } => ("text", Some(cells)),
                };
                let mut v = json!({ "page": p + 1, "kind": kind, "name": c.name, "rect": c.rect.map(|v| (v * 100.0).round() / 100.0) });
                if let Some(cells) = comb {
                    v["comb"] = json!(cells);
                }
                v
            })
            .collect();
        let mut warnings = Vec::new();
        if a.opt_bool("add")?.unwrap_or(true) && !found.is_empty() {
            let (_, out) = self.session.with_own_js_output(id, |s| s.auto_detect_fields(id, &pages)).map_err(failed)?;
            warnings = out.errors;
        }
        Ok(with_warnings(json!({ "fields": list }), warnings))
    }

    pub(crate) fn form_actions(&self, a: &Args) -> Result<Value> {
        use pdfcraft_engine::FieldAction as A;
        let list: Vec<Value> = self
            .doc(a)?
            .field_actions(a.str("field")?)
            .iter()
            .map(|(t, act)| {
                let mut v = match act {
                    A::JavaScript(j) => json!({ "javascript": j }),
                    A::Uri(u) => json!({ "url": u }),
                    A::Reset(f) => json!({ "reset": f }),
                    A::Named(n) => json!({ "menu": n }),
                    A::GoTo(p) => json!({ "page": p + 1 }),
                    A::ShowHide { fields, hide: true } => json!({ "hide": fields }),
                    A::ShowHide { fields, hide: false } => json!({ "show": fields }),
                    A::Submit(u) => json!({ "submit": u }),
                    A::Other(s) => json!({ "other": s }),
                };
                v["trigger"] = json!(t.id());
                v
            })
            .collect();
        Ok(json!({ "field": a.str("field")?, "actions": list }))
    }

    pub(crate) fn form_set_actions(&mut self, a: &Args) -> Result<Value> {
        use pdfcraft_engine::{FieldAction as A, FieldTrigger as T};
        let items = a.get("actions").and_then(Value::as_array).ok_or_else(|| ToolError::InvalidArgs("actions must be an array".into()))?;
        let bad = |m: String| ToolError::InvalidArgs(m);
        let names = |v: &Value| -> Vec<String> {
            v.as_array().map(|x| x.iter().filter_map(|s| s.as_str().map(str::to_string)).collect()).unwrap_or_default()
        };
        let mut acts = Vec::new();
        for it in items {
            let tid = it["trigger"].as_str().unwrap_or("");
            let t = T::from_id(tid).ok_or_else(|| bad(format!("unknown trigger {tid:?}")))?;
            let act = if let Some(j) = it["javascript"].as_str() {
                A::JavaScript(j.into())
            } else if let Some(u) = it["url"].as_str() {
                A::Uri(u.into())
            } else if it.get("reset").is_some() {
                A::Reset(names(&it["reset"]))
            } else if let Some(m) = it["menu"].as_str() {
                A::Named(m.into())
            } else if let Some(p) = it["page"].as_u64() {
                A::GoTo((p.max(1) - 1) as usize)
            } else if it.get("show").is_some() {
                A::ShowHide { fields: names(&it["show"]), hide: false }
            } else if it.get("hide").is_some() {
                A::ShowHide { fields: names(&it["hide"]), hide: true }
            } else if let Some(u) = it["submit"].as_str() {
                A::Submit(u.into())
            } else {
                return Err(bad(format!("{tid}: give one action (javascript, url, reset, menu, page, show, hide or submit)")));
            };
            acts.push((t, act));
        }
        let name = a.str("field")?.to_string();
        let edit =
            pdfcraft_engine::Edit::SetFieldProps { name, props: Box::new(pdfcraft_engine::FieldProps { actions: Some(acts), ..Default::default() }) };
        let id = self.doc(a)?.id;
        let warnings = self.apply_with_warnings(id, edit)?;
        Ok(with_warnings(self.form_actions(a)?, warnings))
    }

    pub(crate) fn js_enabled(&mut self, a: &Args) -> Result<Value> {
        if let Some(on) = a.opt_bool("enabled")? {
            self.session.set_javascript(on);
        }
        Ok(json!({ "enabled": self.session.javascript() }))
    }
}
