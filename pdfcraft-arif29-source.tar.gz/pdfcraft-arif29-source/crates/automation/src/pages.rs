use super::dispatch::Content;
use super::error::{Result, ToolError, failed};
use super::json::{Args, one_based, summary};
use super::{Arc, Automation, DocId, HashMap, PageRenderer, PageText, RenderConfig, RenderRequest, RequestKind, Value, commands, json, tools};

/// Default and maximum resolution for `page_render`.
pub(crate) const DEFAULT_DPI: f64 = 96.0;

pub(crate) const MAX_DPI: f64 = 600.0;

/// `text_find` extracts this many pages first, doubling each batch up to [`FIND_MAX_BATCH`], so a
/// match near the start returns without touching the rest of a long document (#971).
pub(crate) const FIND_FIRST_BATCH: usize = 8;

const FIND_MAX_BATCH: usize = 128;

type PageTexts = Vec<(usize, std::result::Result<Arc<PageText>, String>)>;

pub(crate) const FIND_MAX_WARNINGS: usize = 100;

pub(crate) const FIND_MAX_WARNING_BYTES: usize = 1024;

/// HTML that one `text_extract` with `format: "html"` returns across all its pages; a page past
/// it gets none. `html_truncated` covers this and any page whose own copy hit its caps.
const MAX_EXTRACT_HTML_BYTES: usize = 32 << 20;

impl Automation {
    // ---- pages and text ----------------------------------------------------------------------

    /// 1-based page list → validated 0-based indices.
    pub(crate) fn pages(&self, a: &Args, key: &str) -> Result<Vec<usize>> {
        let n = self.doc(a)?.info.pages.len();
        let pages = one_based(&a.ints(key)?)?;
        if pages.is_empty() {
            return Err(ToolError::InvalidArgs(format!("{key} must list at least one page")));
        }
        if let Some(p) = pages.iter().find(|p| **p >= n) {
            return Err(ToolError::InvalidArgs(format!("page {} is out of range: the document has {n} pages", p + 1)));
        }
        Ok(pages)
    }

    /// A 1-based insertion position (1 = before the first page, n+1 = after the last) → 0-based.
    pub(crate) fn position(&self, a: &Args, key: &str) -> Result<usize> {
        self.opt_position(a, key)?.ok_or_else(|| Args::missing(key))
    }

    /// `position`, but `None` when the key is absent.
    pub(crate) fn opt_position(&self, a: &Args, key: &str) -> Result<Option<usize>> {
        let Some(at) = a.opt_int(key)? else { return Ok(None) };
        let n = self.doc(a)?.info.pages.len();
        if at < 1 || at as usize > n + 1 {
            return Err(ToolError::InvalidArgs(format!("{key} must be between 1 and {} (the document has {n} pages)", n + 1)));
        }
        Ok(Some(at as usize - 1))
    }

    pub(crate) fn renderer(&mut self, id: DocId) -> Result<&mut PageRenderer> {
        let doc = self.session.get(id).ok_or_else(|| failed("no such document"))?;
        // The document's own view settings: layer visibility, hidden comments, reading colours
        // (tools that change one drop this cache so the next render reads it again).
        let config =
            self.session.render_config(id).unwrap_or_else(|| RenderConfig { password: doc.password.as_deref().map(Arc::from), ..Default::default() });
        let fresh = || (doc.display.clone(), PageRenderer::new(doc.display.clone(), config.clone()));
        let entry = self.renderers.entry(id).or_insert_with(fresh);
        if !Arc::ptr_eq(&entry.0, &doc.display) {
            *entry = fresh();
        }
        Ok(&mut entry.1)
    }

    /// The page as a PNG, followed by a JSON part listing the render warnings when there are any,
    /// so a caller can tell that the picture is incomplete, as `pdfcraft-cli render` does (#4340).
    pub(crate) fn page_render(&mut self, a: &Args) -> Result<Vec<Content>> {
        let id = self.doc(a)?.id;
        let page = self.page(a)?;
        let dpi = a.opt_num("dpi")?.unwrap_or(DEFAULT_DPI);
        if !(1.0..=MAX_DPI).contains(&dpi) {
            return Err(ToolError::InvalidArgs(format!("dpi must be between 1 and {MAX_DPI}")));
        }
        let scale = (dpi / 72.0) as f32;
        let block = a.opt_int("hide_text_block")?;
        let added = a.opt_int("hide_added_text")?;
        if block.is_some() && added.is_some() {
            return Err(ToolError::InvalidArgs("choose only one of hide_text_block and hide_added_text".into()));
        }
        let out = if let Some(block) = block {
            if block < 1 {
                return Err(ToolError::InvalidArgs("hide_text_block must be a positive paragraph index from text_paragraphs".into()));
            }
            // The number names the paragraph text_paragraphs listed, as it does for text_edit.
            let doc = self.doc(a)?;
            let index = self.paragraph_index(doc.id, page, block, &doc.text_blocks(page))?;
            doc.text_edit_preview(page, index).map_err(failed)?.render_background(scale).map_err(failed)?
        } else if let Some(added) = added {
            let index = usize::try_from(added)
                .ok()
                .and_then(|n| n.checked_sub(1))
                .ok_or_else(|| ToolError::InvalidArgs("hide_added_text must be a positive added text index from object_list".into()))?;
            self.doc(a)?.added_text_preview(page, index).map_err(failed)?.render_background(scale).map_err(failed)?
        } else {
            self.renderer(id)?.render(RenderRequest { page, kind: RequestKind::Pixels, tile: None, scale, tag: 0, preview: false })
        };
        if let Some(e) = out.error {
            return Err(failed(format!("page {} could not be rendered: {e}", page + 1)));
        }
        rendered_content(&out, page)
    }

    /// A page as RGBA pixels, without encoding a PNG. `page` is 1-based and `scale` is pixels
    /// per point (1.0 = 72 dpi). For an embedder that paints the result straight onto a canvas:
    /// the `page_render` tool only returns PNG, and encoding one to decode it again is wasted
    /// work on every scroll. It uses the same renderer, and the same per-document cache, as
    /// `page_render`.
    pub fn render_pixels(&mut self, doc: u64, page: usize, scale: f32) -> Result<(u32, u32, pdfcraft_render::Pixels)> {
        if !(scale.is_finite() && scale > 0.0 && scale <= (MAX_DPI / 72.0) as f32) {
            return Err(ToolError::InvalidArgs(format!("scale must be between 0 and {}", MAX_DPI / 72.0)));
        }
        let id = DocId(doc);
        let n = self.session.get(id).ok_or_else(|| failed(format!("no open document with id {doc} (see doc_list)")))?.info.pages.len();
        if page < 1 || page > n {
            return Err(ToolError::InvalidArgs(format!("page {page} is out of range: the document has {n} pages")));
        }
        let out = self.renderer(id)?.render(RenderRequest { page: page - 1, kind: RequestKind::Pixels, tile: None, scale, tag: 0, preview: false });
        if let Some(e) = out.error {
            return Err(failed(format!("page {page} could not be rendered: {e}")));
        }
        Ok((out.width, out.height, out.rgba))
    }

    pub(crate) fn page(&self, a: &Args) -> Result<usize> {
        let n = self.doc(a)?.info.pages.len();
        let p = a.int("page")?;
        if p < 1 || p as usize > n {
            return Err(ToolError::InvalidArgs(format!("page {p} is out of range: the document has {n} pages")));
        }
        Ok(p as usize - 1)
    }

    /// The text of `pages` (0-based), from the cache or extracted in parallel.
    pub(crate) fn page_texts(&mut self, id: DocId, pages: &[usize]) -> Result<Vec<Arc<PageText>>> {
        self.page_text_results(id, pages, &mut extract_parallel)?
            .into_iter()
            .map(|(p, text)| text.map_err(|e| failed(format!("page {}: {e}", p + 1))))
            .collect()
    }

    /// Keep per-page failures until the caller chooses strict or partial-result semantics.
    pub(crate) fn page_text_results(
        &mut self,
        id: DocId,
        pages: &[usize],
        extract: &mut impl FnMut(&Arc<Vec<u8>>, Option<Arc<str>>, &[usize]) -> PageTexts,
    ) -> Result<PageTexts> {
        let doc = self.session.get(id).ok_or_else(|| failed("no such document"))?;
        let (bytes, n) = (doc.bytes.clone(), doc.info.pages.len());
        let password: Option<Arc<str>> = doc.password.as_deref().map(Arc::from);
        self.texts.prepare(id, &bytes);
        let mut results = HashMap::new();
        let mut missing = Vec::new();
        for &p in pages {
            if p >= n {
                results.insert(p, Err("page is out of range".to_owned()));
            } else if let Some(text) = self.texts.get(id, p) {
                results.insert(p, Ok(text));
            } else {
                missing.push(p);
            }
        }
        missing.sort_unstable();
        missing.dedup();
        if !missing.is_empty() {
            for (p, text) in extract(&bytes, password, &missing) {
                if let Ok(text) = &text {
                    self.texts.insert(id, p, &bytes, text.clone());
                }
                results.insert(p, text);
            }
        }
        // The batch owns its Arcs: evicting a cache entry cannot lose a requested result. A
        // worker that fails to return a page is an explicit failure, never an empty success.
        Ok(pages.iter().map(|p| (*p, results.get(p).cloned().unwrap_or_else(|| Err("text extraction returned no result".into())))).collect())
    }

    pub(crate) fn text_word_count(&self, a: &Args) -> Result<Value> {
        use pdfcraft_engine::word_count::{self, Counts, Options};
        let doc = self.doc_to_copy(a)?;
        let pages = match a.opt_ints("pages")? {
            Some(_) => self.pages(a, "pages")?,
            None => (0..doc.info.pages.len()).collect(),
        };
        let options = Options {
            exclude_tables: a.opt_bool("exclude_tables")?.unwrap_or(false),
            exclude_code: a.opt_bool("exclude_code")?.unwrap_or(false),
            exclude_images: a.opt_bool("exclude_images")?.unwrap_or(false),
        };
        let report = word_count::count(doc.export_source(), &pages, options, |_| true).map_err(failed)?;
        let counts = |c: Counts| json!({ "words": c.words, "characters": c.characters, "characters_without_spaces": c.characters_without_spaces });
        Ok(json!({
            "total": counts(report.total),
            "pages": report.pages.into_iter().map(|(p, c)| json!({ "page": p + 1, "counts": counts(c) })).collect::<Vec<_>>(),
            "pages_without_text": report.pages_without_text,
            "unclassified_structure": report.unclassified_structure,
        }))
    }

    pub(crate) fn text_extract(&mut self, a: &Args) -> Result<Value> {
        self.text_extract_within(a, MAX_EXTRACT_HTML_BYTES)
    }

    /// [`Self::text_extract`] with at most `html_budget` bytes of HTML across all pages.
    pub(crate) fn text_extract_within(&mut self, a: &Args, html_budget: usize) -> Result<Value> {
        let html = match a.opt_str("format")?.unwrap_or("text") {
            "text" => false,
            "html" => true,
            other => return Err(ToolError::InvalidArgs(format!("format must be \"text\" or \"html\", not {other:?}"))),
        };
        let doc = self.doc_to_copy(a)?;
        let id = doc.id;
        let pages = match a.opt_ints("pages")? {
            Some(_) => self.pages(a, "pages")?,
            None => (0..doc.info.pages.len()).collect(),
        };
        // Column select (#740): only the text inside the rectangle, row by row.
        let rect = a.nums::<4>("rect")?.map(|r| r.map(|v| v as f32));
        let texts = self.page_texts(id, &pages)?;
        let text = |t: &PageText| match rect {
            Some(r) => t.column_text(&t.glyphs_in(r)),
            None => t.plain_text(),
        };
        let doc = self.doc(a)?;
        let mut out = Vec::with_capacity(pages.len());
        // `spent`: the budget ran out, so later pages get no HTML. `cut`: some page's HTML is
        // missing part of its text, by the budget or by the copy's own caps.
        let (mut html_left, mut spent, mut cut) = (html_budget, false, false);
        for (&p, t) in pages.iter().zip(texts) {
            let mut page = json!({ "page": p + 1, "text": text(&t) });
            // Content cut at the renderer's limits (#623): the text is incomplete, and said so.
            if t.truncated {
                page["truncated"] = json!(true);
            }
            if html {
                // Copy with formatting: the same glyphs as an HTML fragment, within one budget for
                // the whole call; a page past it gets none and the call says so.
                let mut copy = pdfcraft_engine::RichCopy::default();
                if !spent {
                    let glyphs: Vec<usize> = match rect {
                        Some(r) => t.glyphs_in(r),
                        None => (0..t.glyphs.len()).collect(),
                    };
                    copy = doc.rich_copy(p, &t, &glyphs).map_err(failed)?;
                    match html_left.checked_sub(copy.html.len()) {
                        Some(left) => html_left = left,
                        None => {
                            spent = true;
                            copy = pdfcraft_engine::RichCopy::default();
                        }
                    }
                }
                cut |= spent || copy.truncated;
                page["html"] = json!(copy.html);
                page["styles_incomplete"] = json!(copy.styles_incomplete || spent);
            }
            out.push(page);
        }
        let mut result = json!({ "pages": out });
        if html {
            result["html_truncated"] = json!(cut);
        }
        Ok(result)
    }

    /// Matches in document order, extracting page text in growing batches and stopping as soon as
    /// `limit` is reached, so a bounded search doesn't extract (and cache) the whole document
    /// (#971). One match past the limit supplies `next`. Reached extraction failures are reported
    /// as bounded warnings; `complete` requires both no continuation and no failed pages.
    /// `stop_at_limit` drops that lookahead: the search ends at the `limit`th match, so a lone match
    /// never sends it to the end of the document, and `next` is only where to resume (#5328).
    pub(crate) fn text_find(&mut self, a: &Args) -> Result<Value> {
        self.text_find_with(a, &mut extract_parallel)
    }

    pub(crate) fn text_find_with(
        &mut self,
        a: &Args,
        extract: &mut impl FnMut(&Arc<Vec<u8>>, Option<Arc<str>>, &[usize]) -> PageTexts,
    ) -> Result<Value> {
        let doc = self.doc(a)?;
        let (id, n) = (doc.id, doc.info.pages.len());
        let query = a.str("query")?;
        let limit = usize::try_from(a.opt_int("limit")?.unwrap_or(500).max(1)).unwrap_or(usize::MAX);
        let start = match a.opt_int("start_page")? {
            None => 0,
            Some(p) if p >= 1 && usize::try_from(p).is_ok_and(|p| p <= n) => usize::try_from(p - 1).unwrap_or(0),
            Some(p) => return Err(ToolError::InvalidArgs(format!("start_page {p} is out of range: the document has {n} pages"))),
        };
        let skip = usize::try_from(a.opt_int("skip")?.unwrap_or(0).max(0)).unwrap_or(usize::MAX);
        let stop_at_limit = a.opt_bool("stop_at_limit")?.unwrap_or(false);
        let mut matches = Vec::new();
        let mut next = None;
        let mut stopped = false;
        let mut warnings = Vec::new();
        let mut warning_count = 0usize;
        // A search that stops at its limit starts with one page, so a match on it reads nothing
        // more; the batches still double for a match further in.
        let (mut first, mut batch) = (start, if stop_at_limit { 1 } else { FIND_FIRST_BATCH });
        'search: while first < n {
            let end = first.saturating_add(batch).min(n);
            let pages: Vec<usize> = (first..end).collect();
            let texts = self.page_text_results(id, &pages, extract)?;
            for (p, text) in texts {
                let text = match text {
                    Ok(text) => text,
                    Err(mut error) => {
                        warning_count += 1;
                        if warnings.len() < FIND_MAX_WARNINGS {
                            let end = error.floor_char_boundary(FIND_MAX_WARNING_BYTES.min(error.len()));
                            let truncated = end < error.len();
                            error.truncate(end);
                            warnings.push(json!({ "page": p + 1, "error": error, "error_truncated": truncated }));
                        }
                        continue;
                    }
                };
                let skip_here = if p == start { skip } else { 0 };
                // One extra match proves that the caller needs a continuation. Include skipped
                // matches on the starting page when bounding the temporary per-page result.
                let needed = limit.saturating_sub(matches.len()).saturating_add(skip_here).saturating_add(usize::from(!stop_at_limit));
                for (k, r) in text.find_opts_limited(query, false, false, needed).into_iter().enumerate().skip(skip_here) {
                    if matches.len() == limit {
                        next = Some(json!({ "start_page": p + 1, "skip": k }));
                        break 'search;
                    }
                    matches.push(json!({ "page": p + 1, "text": text.text_of(r.clone()), "rects": text.line_rects(r) }));
                    if stop_at_limit && matches.len() == limit {
                        // Resume just past this match; whether another exists isn't looked at.
                        next = Some(json!({ "start_page": p + 1, "skip": k.saturating_add(1) }));
                        stopped = true;
                        break 'search;
                    }
                }
            }
            first = end;
            batch = batch.saturating_mul(2).min(FIND_MAX_BATCH);
        }
        let mut out = json!({ "query": query, "count": matches.len(), "complete": next.is_none() && warning_count == 0, "matches": matches,
            "warnings_truncated": warning_count > warnings.len(), "warning_count": warning_count, "warnings": warnings });
        if let Some(o) = out.as_object_mut() {
            if let Some(next) = next {
                o.insert("next".into(), next);
            }
            if stop_at_limit {
                o.insert("stopped_at_limit".into(), stopped.into());
            }
        }
        Ok(out)
    }

    /// Find and replace (Edit text ▸ Replace): every match (or the first) rewritten inside its
    /// own paragraph through the same engine plan as the window's Replace all, one undo step.
    /// The page text is searched too (as `text_find` does), so matches no paragraph holds are
    /// counted as not editable and the counts add up to what `text_find` reports.
    pub(crate) fn text_replace(&mut self, a: &Args) -> Result<Value> {
        self.text_replace_with(a, &mut extract_parallel)
    }

    pub(crate) fn text_replace_with(
        &mut self,
        a: &Args,
        extract: &mut impl FnMut(&Arc<Vec<u8>>, Option<Arc<str>>, &[usize]) -> PageTexts,
    ) -> Result<Value> {
        let doc = self.doc(a)?;
        let (id, n) = (doc.id, doc.info.pages.len());
        let pages = match a.opt_ints("pages")? {
            Some(_) => self.pages(a, "pages")?,
            None => (0..n).collect(),
        };
        let query = pdfcraft_engine::find_replace::Replace {
            find: a.str("find")?.to_owned(),
            with: a.str("replace")?.to_owned(),
            case_sensitive: a.opt_bool("case_sensitive")?.unwrap_or(false),
            whole_words: a.opt_bool("whole_words")?.unwrap_or(false),
        };
        let all = a.opt_bool("all")?.unwrap_or(true);
        let mut pages = pages;
        pages.sort_unstable();
        pages.dedup();
        // Pages whose text the find bar couldn't read, reported with the plan, not dropped.
        let mut unreadable: Vec<(usize, String)> = Vec::new();
        let (which, found) = if all {
            let mut found = std::collections::BTreeMap::new();
            for (p, text) in self.page_text_results(id, &pages, &mut *extract)? {
                match text {
                    Ok(text) => {
                        found.insert(p, text.find_opts(&query.find, query.case_sensitive, query.whole_words).len());
                    }
                    Err(e) => unreadable.push((p, e)),
                }
            }
            unreadable.sort();
            (Some(pdfcraft_engine::find_replace::Which::All), Some(found))
        } else {
            // The first match the find bar shows, and that one only: pages are read in order until
            // one holds a match, and a page that can't be read stops the search there.
            let mut texts = Vec::new();
            let (mut start, mut batch) = (0, FIND_FIRST_BATCH.max(1));
            'search: while start < pages.len() {
                let end = pages.len().min(start.saturating_add(batch));
                let mut results: std::collections::HashMap<usize, _> =
                    self.page_text_results(id, &pages[start..end], &mut *extract)?.into_iter().collect();
                for p in &pages[start..end] {
                    match results.remove(p) {
                        Some(Ok(text)) if text.find_opts_limited(&query.find, query.case_sensitive, query.whole_words, 1).is_empty() => {}
                        Some(Ok(text)) => {
                            texts.push((*p, text));
                            break 'search;
                        }
                        Some(Err(e)) => {
                            unreadable.push((*p, e));
                            break 'search;
                        }
                        None => {}
                    }
                }
                start = end;
                batch = batch.saturating_mul(2).min(FIND_MAX_BATCH);
            }
            (pdfcraft_engine::find_replace::Which::first_in(texts.iter().map(|(p, t)| (*p, t.as_ref())), &query), None)
        };
        let mut plan = match which {
            Some(which) => self.doc(a)?.plan_replace(&pages, &query, which, found.as_ref()).map_err(failed)?,
            None => {
                // Nothing to replace: still the permission and query checks of a plan.
                self.doc(a)?.plan_replace(&[], &query, pdfcraft_engine::find_replace::Which::All, None).map_err(failed)?
            }
        };
        for (p, e) in &unreadable {
            plan.unreadable_page(*p, e);
        }
        let mut out = match plan.edit.clone() {
            Some(edit) => self.apply(a, edit)?,
            None => summary(self.doc(a)?),
        };
        let skipped: serde_json::Map<String, Value> = plan.skipped.iter().map(|(why, k)| (why.key().to_owned(), json!(k))).collect();
        out["replaced"] = json!(plan.replaced);
        out["changed"] = json!(plan.edit.is_some());
        out["pages"] = json!(plan.pages.iter().map(|p| p + 1).collect::<Vec<_>>());
        out["skipped"] = json!(plan.skipped_total());
        out["skipped_by"] = Value::Object(skipped);
        if !plan.refusals.is_empty() {
            out["refusals"] = json!(plan.refusals);
        }
        Ok(out)
    }

    pub(crate) fn command_list(&self, a: &Args) -> Result<Value> {
        let active = match a.opt_int("doc")? {
            Some(_) => Some(self.doc(a)?.id),
            None => None,
        };
        let filter = a.opt_str("filter")?.unwrap_or("").to_lowercase();
        let enabled_only = a.opt_bool("enabled_only")?.unwrap_or(false);
        let list: Vec<Value> = commands::COMMANDS
            .iter()
            .map(|c| {
                json!({
                    "id": c.id,
                    "label": commands::current_label(c, &self.session, active),
                    "menu": c.menu,
                    "shortcut": c.shortcut.map(|s| s.label(cfg!(target_os = "macos"))),
                    "enabled": commands::is_enabled(c, &self.session, active),
                    "tool": tools::tool_for_command(c.id),
                    "params": tools::tool_for_command(c.id).and_then(tools::find).map(|t| &t.input_schema),
                })
            })
            .collect();
        let list: Vec<Value> = list
            .into_iter()
            .filter(|c| {
                (!enabled_only || c.get("enabled").and_then(Value::as_bool) == Some(true))
                    && (filter.is_empty()
                        || ["id", "label", "menu"].iter().any(|k| c.get(k).is_some_and(|v| v.to_string().to_lowercase().contains(&filter))))
            })
            .collect();
        Ok(json!({ "commands": list }))
    }
}

/// A rendered raster as PNG, through the engine's encoder (Export ▸ Image writes the same).
pub(crate) fn encode_png(width: u32, height: u32, premultiplied: &[u8]) -> Result<Vec<u8>> {
    pdfcraft_engine::export::encode_png(width, height, premultiplied).map_err(failed)
}

/// The output of a page-rendering tool: the PNG of the 0-based `page`, followed by a JSON part
/// listing its render warnings when there are any. Without warnings it is the PNG alone, as it
/// always was.
pub(crate) fn rendered_content(out: &pdfcraft_render::RenderedPage, page: usize) -> Result<Vec<Content>> {
    let data = encode_png(out.width, out.height, &out.rgba)?;
    let mut content = vec![Content::Png { data, width: out.width, height: out.height }];
    if !out.warnings.is_empty() {
        // Sentences, like the other tools' `warnings`, so command_run can add its own to the list.
        let warnings: Vec<&str> = out.warnings.iter().map(|&w| render_warning_text(w)).collect();
        content.push(Content::Json(json!({ "page": page.saturating_add(1), "warnings": warnings })));
    }
    Ok(content)
}

/// What a render warning means, in the words `pdfcraft-cli render` prints for it.
fn render_warning_text(warning: pdfcraft_render::RenderWarning) -> &'static str {
    use pdfcraft_render::RenderWarning;
    match warning {
        RenderWarning::ContentTruncated => {
            "content past the page's safety budget, or a picture whose JBIG2 mask is past a decoder limit, was skipped"
        }
        RenderWarning::ColourFallback => "a colour that could not be computed was painted in a fallback colour",
        RenderWarning::MalformedIndexedImage => "an image with a malformed Indexed colour table may be drawn wrongly or not at all",
        RenderWarning::Type3WidthsMissing => "a Type 3 font has no /Widths; its glyphs were spaced by the widths their glyph procedures give",
    }
}

/// Extract the text of `pages` (0-based) with one renderer per worker thread.
pub(crate) fn extract_parallel(bytes: &Arc<Vec<u8>>, password: Option<Arc<str>>, pages: &[usize]) -> PageTexts {
    let extract = |r: &mut PageRenderer, p: usize| {
        let out = r.render(RenderRequest { page: p, kind: RequestKind::Text, tile: None, scale: 1.0, tag: 0, preview: false });
        match out.error {
            Some(e) => Err(e),
            None => Ok(out.text.unwrap_or_default()),
        }
    };
    let config = RenderConfig { password, ..Default::default() };
    let workers = if cfg!(target_arch = "wasm32") { 1 } else { std::thread::available_parallelism().map_or(1, std::num::NonZeroUsize::get).min(8) };
    // Small jobs aren't worth a second parse of the document.
    if workers == 1 || pages.len() < 8 {
        let mut r = PageRenderer::new(bytes.clone(), config);
        return pages.iter().map(|p| (*p, extract(&mut r, *p))).collect();
    }
    let next = std::sync::atomic::AtomicUsize::new(0);
    let mut out: PageTexts = std::thread::scope(|s| {
        let handles: Vec<_> = (0..workers)
            .map(|_| {
                s.spawn(|| {
                    let mut r = PageRenderer::new(bytes.clone(), config.clone());
                    let mut done = Vec::new();
                    loop {
                        let i = next.fetch_add(1, std::sync::atomic::Ordering::Relaxed);
                        let Some(p) = pages.get(i) else { break };
                        done.push((*p, extract(&mut r, *p)));
                    }
                    done
                })
            })
            .collect();
        handles.into_iter().flat_map(|h| h.join().unwrap_or_default()).collect()
    });
    out.sort_by_key(|(p, _)| *p);
    out
}
